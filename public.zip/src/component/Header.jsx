

const Header = () => {
    return (
        <div>
            <h1>This is header section</h1>
        </div>
    );
};

export default Header;