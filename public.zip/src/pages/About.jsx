

const About = () => {
  return (
  
       <>
   <section
     className="about-us about-features pt-12 pb-8"
     style="backgroundImage: url(assets/images/testimonial-1.png)"
   >
     <div className="container">
       <div className="about-image-box">
         <div className="row d-flex align-items-center justify-content-between">
           <div className="col-lg-7 pe-lg-4">
             <div
               className="about-features"
               style="backgroundImage: url(assets/images/contentbg.png)"
             >
               <div className="row align-items-center">
                 <div className="col-lg-6">
                   <div
                     className="features-infobox border-all p-5 box-shadow bg-white text-center mb-4"
                   >
                     <div className="infobox-icon mb-2">
                       <i className="fa fa-users fs-1 theme"></i>
                     </div>
                     <div className="box-body">
                       <h4 className="infobox-title">Event Conferences</h4>
                       <p className="mb-2">
                         Duis aute irure dolor in reprehenderit
                       </p>
                       <a href="#" className="theme"
                         >Learn More <i className="fa fa-angle-right"></i
                       ></a>
                     </div>
                   </div>
                   <div
                     className="features-infobox border-all p-5 box-shadow bg-white text-center mb-4"
                   >
                     <div className="infobox-icon mb-2">
                       <i className="fa fa-flag fs-1 theme"></i>
                     </div>
                     <div className="box-body">
                       <h4 className="infobox-title">Culture Leadership</h4>
                       <p className="mb-2">
                         Duis aute irure dolor in reprehenderit
                       </p>
                       <a href="#" className="theme"
                         >Learn More <i className="fa fa-angle-right"></i
                       ></a>
                     </div>
                   </div>
                 </div>
                 <div className="col-lg-6">
                   <div
                     className="features-infobox border-all p-5 box-shadow bg-white text-center mb-4"
                   >
                     <div className="infobox-icon mb-2">
                       <i className="fa fa-gear fs-1 theme"></i>
                     </div>
                     <div className="box-body">
                       <h4 className="infobox-title">Digital Marketing</h4>
                       <p className="mb-2">
                         Duis aute irure dolor in reprehenderit
                       </p>
                       <a href="#" className="theme"
                         >Learn More <i className="fa fa-angle-right"></i
                       ></a>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
           </div>
           <div className="col-lg-5 ps-lg-4">
             <div className="about-content text-center text-lg-start mb-4">
               <h4 className="h-title">Events</h4>
               <div
                 className="selector4"
                 style={{display: 'flex', justifyContent: 'center'}}
               >
                 <h2 className="ah-headline">
                   <span>Why You Should Join The</span>
                   <span className="ah-words-wrapper white theme">
                     <b className="is-visible textcap">Events?</b>
                     <b>Events?</b>
                   </span>
                 </h2>
               </div>
               <p className="mb-4">
                 Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                 do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                 Quis ip suspendisse ultrices gravida. Risus commodo
               </p>
               <a href="event-detail.html" className="nir-btn"
                 >Join Event <i className="fa fa-angle-right"></i
               ></a>
             </div>
           </div>
         </div>
       </div>
     </div>
   </section>
   {/* <!-- about-us ends --> */}

   {/* <!-- about-us starts --> */}
   <section className="about-us about-before pt-12">
     <div className="container">
       <div className="about-image-box">
         <div className="row d-flex align-items-center justify-content-between">
           <div className="col-lg-5 pe-4">
             <div
               className="about-content section-title text-lg-start text-center mb-4"
             >
               <h3 className="h-title">About</h3>
               <h4 className="theme">Conference Organisation</h4>
               <div
                 className="selector4"
                 style={{display: 'flex', justifyContent: 'center'}}
               >
                 <h2 className="ah-headline">
                   <span>Conference, Seminars &</span>
                   <span className="ah-words-wrapper white theme">
                     <b className="is-visible textcap">Events</b>
                     <b>Events</b>
                   </span>
                 </h2>
               </div>
               <p className="mb-4">
                 Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                 do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                 Quis ip suspendisse ultrices gravida. Risus commodo
               </p>
               <a href="about.html" className="nir-btn"
                 >Discover Now <i className="fa fa-angle-right"></i
               ></a>
             </div>
           </div>
           <div className="col-lg-7 ps-4">
             <div
               className="about-features"
               style="backgroundImage: url(assets/images/contentbg.png)"
             >
               <div className="row align-items-center">
                 <div className="col-lg-6 mb-4">
                   <img src="assets/images/about/busi-3.jpg" alt="" />
                 </div>
                 <div className="col-lg-6">
                   <img
                     src="assets/images/about/busi-1.jpg"
                     alt=""
                     className="mb-4"
                   />
                   <img src="assets/images/about/busi-2.jpg" alt="" />
                 </div>
               </div>
             </div>
           </div>
         </div>
       </div>
     </div>
   </section>
 
</>
  
  );
};

export default About;
